"""insurance_analysis.py

Insurance Data Analysis + Baseline Model (Linear Regression)

Dataset expected columns:
- age, sex, bmi, children, smoker, region, charges

This module provides helper functions used by the notebook.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Tuple

import numpy as np
import pandas as pd

from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import r2_score


CATEGORICAL_COLS = ["sex", "smoker", "region"]
NUMERIC_COLS = ["age", "bmi", "children"]
TARGET_COL = "charges"


def load_insurance_data(path: str) -> pd.DataFrame:
    """Load insurance.csv into a DataFrame."""
    return pd.read_csv(path)


def report_basic_info(df: pd.DataFrame) -> Dict[str, object]:
    """Return basic info used for quick reporting."""
    return {
        "shape": df.shape,
        "dtypes": df.dtypes,
        "missing": df.isna().sum(),
    }


def fill_missing_values(df: pd.DataFrame) -> pd.DataFrame:
    """Fill missing values: numeric -> median, categorical -> mode."""
    out = df.copy()
    for col in out.columns:
        if out[col].isna().sum() == 0:
            continue
        if pd.api.types.is_numeric_dtype(out[col]):
            out[col] = out[col].fillna(out[col].median())
        else:
            mode = out[col].mode(dropna=True)
            fill_val = mode.iloc[0] if len(mode) else "Unknown"
            out[col] = out[col].fillna(fill_val)
    return out


def preprocess_for_model(df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.Series]:
    """Prepare X, y for modeling. One-hot encode categorical columns."""
    if TARGET_COL not in df.columns:
        raise ValueError(f"Target column '{TARGET_COL}' not found.")
    df2 = df.copy()

    # Ensure types
    df2["age"] = pd.to_numeric(df2["age"], errors="coerce")
    df2["bmi"] = pd.to_numeric(df2["bmi"], errors="coerce")
    df2["children"] = pd.to_numeric(df2["children"], errors="coerce")
    df2[TARGET_COL] = pd.to_numeric(df2[TARGET_COL], errors="coerce")

    df2 = df2.dropna(axis=0, how="any").copy()

    y = df2[TARGET_COL]
    X = df2.drop(columns=[TARGET_COL])

    # One-hot encode categorical columns (drop_first to avoid multicollinearity)
    X = pd.get_dummies(X, columns=[c for c in CATEGORICAL_COLS if c in X.columns], drop_first=True)
    return X, y


@dataclass
class ModelResult:
    model: LinearRegression
    r2_train: float
    r2_test: float
    X_train_shape: Tuple[int, int]
    X_test_shape: Tuple[int, int]


def train_linear_regression(
    df: pd.DataFrame,
    test_size: float = 0.30,
    random_state: int = 42,
) -> ModelResult:
    """Train LinearRegression and return R² on train/test."""
    df_filled = fill_missing_values(df)
    X, y = preprocess_for_model(df_filled)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state
    )

    lr = LinearRegression()
    lr.fit(X_train, y_train)

    r2_train = r2_score(y_train, lr.predict(X_train))
    r2_test = r2_score(y_test, lr.predict(X_test))

    return ModelResult(
        model=lr,
        r2_train=float(r2_train),
        r2_test=float(r2_test),
        X_train_shape=X_train.shape,
        X_test_shape=X_test.shape,
    )
